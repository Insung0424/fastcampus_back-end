package UI;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class CreateAccount {

	private JFrame frame;
	private JTextField idTf;
	private JTextField nameTf;
	private JTextField yearTf;
	private JTextField phoneTf;
	private JPasswordField passTf;
	private JPasswordField passReTf;
	private JTextField emailTf;
	private JComboBox MonthCB;
	
	String year = "", month = "", day = "";
	   String id = "", pass = "", passRe = "", name = "", sex = "", email = "", phone = "";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreateAccount window = new CreateAccount();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CreateAccount() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.BLACK);
		frame.getContentPane().setLayout(null);
		
		nameTf = new JTextField();
		nameTf.setColumns(10);
		nameTf.setBounds(259, 249, 266, 33);
		frame.getContentPane().add(nameTf);
		
		yearTf = new JTextField();
		yearTf.setColumns(10);
		yearTf.setBounds(259, 303, 88, 33);
		frame.getContentPane().add(yearTf);
		
		emailTf = new JTextField();
		emailTf.setColumns(10);
		emailTf.setBounds(259, 455, 266, 33);
		frame.getContentPane().add(emailTf);
		
		phoneTf = new JTextField();
		phoneTf.setColumns(10);
		phoneTf.setBounds(259, 350, 266, 33);
		frame.getContentPane().add(phoneTf);
		
		idTf = new JTextField();
		idTf.setColumns(10);
		idTf.setBounds(259, 82, 266, 33);
		frame.getContentPane().add(idTf);
		
		
		JLabel lblNewLabel = new JLabel("\uC544\uC774\uB514 : ");
		lblNewLabel.setFont(new Font("�޸ո���T", Font.PLAIN, 20));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(171, 82, 93, 33);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("\uBE44\uBC00\uBC88\uD638 :");
		lblPassword.setForeground(Color.WHITE);
		lblPassword.setFont(new Font("�޸ո���T", Font.PLAIN, 20));
		lblPassword.setBounds(155, 135, 85, 33);
		frame.getContentPane().add(lblPassword);
		
		JLabel lblNewLabel_2 = new JLabel("\uBE44\uBC00\uBC88\uD638 \uD655\uC778 : ");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("�޸ո���T", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(110, 192, 142, 33);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\uC774\uB984 : ");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("�޸ո���T", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(185, 249, 62, 33);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("\uC0DD\uB144\uC6D4\uC77C : ");
		lblNewLabel_4.setForeground(Color.WHITE);
		lblNewLabel_4.setFont(new Font("�޸ո���T", Font.PLAIN, 20));
		lblNewLabel_4.setBounds(154, 303, 93, 33);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("\uD578\uB4DC\uD3F0\uBC88\uD638 : ");
		lblNewLabel_5.setForeground(Color.WHITE);
		lblNewLabel_5.setFont(new Font("�޸ո���T", Font.PLAIN, 20));
		lblNewLabel_5.setBounds(140, 453, 116, 33);
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblPassword_1 = new JLabel("\uD2B9\uC218\uBB38\uC790 + 8\uC790");
		lblPassword_1.setForeground(Color.LIGHT_GRAY);
		lblPassword_1.setFont(new Font("�޸ո���T", Font.PLAIN, 20));
		lblPassword_1.setBounds(551, 137, 128, 33);
		frame.getContentPane().add(lblPassword_1);
		
		MonthCB = new JComboBox<String>(
	            new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" });
		MonthCB.setBounds(359, 303, 77, 33);
		frame.getContentPane().add(MonthCB);
		
		JComboBox DayCB = new JComboBox();
		DayCB.setModel(new DefaultComboBoxModel(new String[] {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		DayCB.setBounds(448, 303, 77, 33);
		frame.getContentPane().add(DayCB);
		
		JLabel emailLB = new JLabel("�̸��� : ");
		emailLB.setForeground(Color.WHITE);
		emailLB.setFont(new Font("�޸ո���T", Font.PLAIN, 20));
		emailLB.setBounds(185, 350, 80, 33);
		frame.getContentPane().add(emailLB);
		
		JLabel GenderLB = new JLabel("\uC131\uBCC4 : ");
		GenderLB.setForeground(Color.WHITE);
		GenderLB.setFont(new Font("�޸ո���T", Font.PLAIN, 20));
		GenderLB.setBounds(185, 391, 62, 33);
		frame.getContentPane().add(GenderLB);
		
		JRadioButton MaleRB = new JRadioButton("\uB0A8\uC790");
		MaleRB.setFont(new Font("�޸ո���T", Font.PLAIN, 16));
		MaleRB.setForeground(Color.WHITE);
		MaleRB.setBackground(Color.BLACK);
		MaleRB.setBounds(259, 397, 88, 23);
		frame.getContentPane().add(MaleRB);
		
		JRadioButton FemaleRB = new JRadioButton("\uC5EC\uC790");
		FemaleRB.setFont(new Font("�޸ո���T", Font.PLAIN, 16));
		FemaleRB.setForeground(Color.WHITE);
		FemaleRB.setBackground(Color.BLACK);
		FemaleRB.setBounds(359, 397, 88, 23);
		frame.getContentPane().add(FemaleRB);
		
		ButtonGroup g1 = new ButtonGroup();
		g1.add(MaleRB);
		g1.add(FemaleRB);
		
		JButton Registerbtn = new JButton("\uD68C\uC6D0\uAC00\uC785");
		Registerbtn.setForeground(Color.BLACK);
		Registerbtn.setBackground(Color.WHITE);
		Registerbtn.setFont(new Font("�޸ո���T", Font.PLAIN, 20));
		Registerbtn.setBounds(582, 479, 168, 55);
		frame.getContentPane().add(Registerbtn);
		
		passTf = new JPasswordField();
		passTf.setBounds(259, 137, 268, 33);
		frame.getContentPane().add(passTf);
		
		passReTf = new JPasswordField();
		passReTf.setBounds(259, 194, 268, 33);
		frame.getContentPane().add(passReTf);
		
		JButton Backbtn = new JButton();
		Backbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LottoLogin n = new LottoLogin();
				n.setVisible(true);
				frame.dispose();
			}
		});
		Backbtn.setBackground(Color.WHITE);
		Backbtn.setIcon(new ImageIcon("C:\\Users\\User\\Downloads\\left-arrow (2).png"));
		Backbtn.setBounds(30, 30, 55, 44);
		frame.getContentPane().add(Backbtn);
		frame.setTitle("ȸ������");
		frame.setBounds(100, 100, 800, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	

	
	MonthCB.addActionListener(new ActionListener() {

		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == MonthCB) {
				JComboBox monthBox = (JComboBox) e.getSource();
				month = (String) monthBox.getSelectedItem();
			}

		}
	});
	
	DayCB.addActionListener(new ActionListener() {

		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if (e.getSource() == DayCB) {
				JComboBox dayBox = (JComboBox) e.getSource();
				day = (String) dayBox.getSelectedItem();
			}
		}
	});

	MaleRB.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {
            // TODO Auto-generated method stub
            sex = "M";
         }
      });

	FemaleRB.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {
            // TODO Auto-generated method stub
            sex = "F";
         }
      });

	Registerbtn.addActionListener(new ActionListener() {      //ȸ�����Թ�ư

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			id = idTf.getText();
            pass = new String(passTf.getPassword());
            passRe = new String(passReTf.getPassword());
            name = nameTf.getText();
            year = yearTf.getText();
            email = emailTf.getText();
            phone = phoneTf.getText();


			String sql = "insert into copy_member_signup(m_id, m_pw, m_name, m_birth, m_gender, m_email, m_phone) values (?,?,?,?,?,?,?)";

            Pattern passPattern1 = Pattern.compile("^(?=.*\\d)(?=.*[a-zA-Z]).{4,10}$"); //4~10�� ���� ���� ����
            Matcher passMatcher = passPattern1.matcher(pass);

            if (!passMatcher.find()) {
               JOptionPane.showMessageDialog(null, "��й�ȣ�� ����+���� 4�� �̻�� �����Ǿ�� �մϴ�", "��й�ȣ ����", 1);

			} else if (!pass.equals(passRe)) {
				JOptionPane.showMessageDialog(null, "��й�ȣ�� ���� ���� �ʽ��ϴ�", "��й�ȣ ����", 1);

			} else {
				try {
					Connection conn = LottoLogin.getConnection();

	                  PreparedStatement pstmt = conn.prepareStatement(sql);

	                  String date = yearTf.getText() + month + day;

	                  pstmt.setString(1, idTf.getText());
	                  pstmt.setString(2, pass);
	                  pstmt.setString(3, nameTf.getText());
	                  pstmt.setString(4, date);
	                  pstmt.setString(5, sex);
	                  pstmt.setString(6, phoneTf.getText());
	                  pstmt.setString(7, emailTf.getText());


					int r = pstmt.executeUpdate();
					System.out.println("����� row " + r);
					JOptionPane.showMessageDialog(null, "ȸ�� ���� �Ϸ�!", "ȸ������", 1);
					
					LottoLogin n = new LottoLogin();
					n.setVisible(true);
					frame.dispose();// �� �Ϸ�Ǹ� �α��� ȭ������
				} catch (SQLException e1) {
					System.out.println("SQL error" + e1.getMessage());
					if (e1.getMessage().contains("PRIMARY")) {
						JOptionPane.showMessageDialog(null, "���̵� �ߺ�!", "���̵� �ߺ� ����", 1);
					} else
						JOptionPane.showMessageDialog(null, "������ ����� �Է����ּ���!", "����", 1);
				} // try ,catch
			}
		}
	});
}

	public void setVisible(boolean b) {
		frame.setVisible(b);
		
	}
}


