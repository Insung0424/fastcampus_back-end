package lottomaxrecord;

public interface maxRecord {
	public String SelectQuery(String q);
}
